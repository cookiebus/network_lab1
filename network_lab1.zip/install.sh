sudo apt-get install python-pip
sudo apt-get install python-dev
sudo apt-get install postgresql
sudo apt-get install libpq-dev
sudo apt-get install git
